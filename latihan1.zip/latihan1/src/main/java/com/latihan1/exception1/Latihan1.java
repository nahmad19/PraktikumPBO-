package com.latihan1.exception1;

import java.util.Scanner;

public class Latihan1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int pembilang, penyebut, hasil;
        System.out.print("Masukan pembilang >> ");
        pembilang = input.nextInt();
        System.out.print("Masukan penyebut >> ");
        penyebut = input.nextInt();
        hasil = pembilang / penyebut;
        System.out.println(pembilang + " / " + penyebut + " = " + hasil);
    }
    
}

